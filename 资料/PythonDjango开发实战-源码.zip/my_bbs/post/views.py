from django.conf import settings
from django.contrib.auth.decorators import login_required, permission_required
# from django.core.signals import request_started, request_finished
from django.core.management import get_commands
from django.db.models import F
# from django.dispatch import receiver
# from django.db.models.signals import post_save
from django.http import HttpResponse, JsonResponse, HttpResponseRedirect, HttpResponseBadRequest

# Create your views here.
from django.shortcuts import redirect, render
from django.template import Context, Template, RequestContext
from django.template.loader import get_template
from django.urls import reverse
from django.urls.converters import IntConverter
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.cache import cache_page
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_GET


import time

from django.views.generic import ListView, TemplateView, RedirectView, DetailView

from post.forms import TopicSearchForm, TopicModelForm
from post.models import Topic, Comment
from post.post_service import build_topic_base_info, build_topic_detail_info, add_comment_to_topic


def exec_time(func):
    def wrapper(*args, **kwargs):
        start = time.time()
        res = func(*args, **kwargs)
        print('%ss elapsed for %s' % (time.time() - start, func.__name__))
        return res
    return wrapper


def project_signature(request):
    return {'project': 'Django BBS'}


class CustomException(Exception):
    pass


from post.signals import register_signal


# @cache_page(60 * 15)
def hello_django_bbs(request):
    # import time
    # time.sleep(10)
    print(register_signal.send(hello_django_bbs, request=request, user=request.user))

    # print('hello_django_bbs')
    # print(type(request.COOKIES))
    # session_key = request.COOKIES.get(settings.SESSION_COOKIE_NAME)
    # print(session_key)
    # print(type(request.user))
    # print(get_commands())
    # return JsonResponse({'hello': 'django'})
    # def render():
    #     print('hello_django_bbs: render')
    #     raise Exception('hhahhah')
    #     return JsonResponse({'hello': 'django'})
    #
    # response = HttpResponse()
    # response.render = render
    # return response

    # raise Exception('hello_django_bbs error')
    # topic_qs = Topic.objects.all()
    # comment_qs = Comment.objects.all()
    # # return render(request, 'post/model_content.html', {'model': comment_qs, 'name': 'Comment'})
    # # return render(request, 'post/hello_django_bbs.html', {'signature': ('Django', 'BBS', 'xxx')})
    t = Template('<h1>Hello {{ project }}, {{ user.username }}</h1>')
    c = RequestContext(request, processors=[project_signature])
    html = t.render(c)
    return HttpResponse(html)
    # raise CustomException('x')
    # return JsonResponse({'hello': 'django'})


@csrf_exempt
def request_property(request):
    """
    request 属性
    :param request:
    :return:
    """
    property_key = ['path', 'method']
    result = {}
    for pk in property_key:
        result[pk] = request.__dict__[pk]
    result['name'] = request.user.username
    result['scheme'] = request.scheme
    # result['META'] = request.META
    # result['COOKIES'] = request.COOKIES

    # META 中的数据
    result['CONTENT_LENGTH'] = request.META['CONTENT_LENGTH']
    result['CONTENT_TYPE'] = request.META['CONTENT_TYPE']
    result['HTTP_HOST'] = request.META['HTTP_HOST']
    result['HTTP_USER_AGENT'] = request.META['HTTP_USER_AGENT']
    result['REMOTE_ADDR'] = request.META['REMOTE_ADDR']
    result['REMOTE_HOST'] = request.META['REMOTE_HOST']
    result['REQUEST_METHOD'] = request.META['REQUEST_METHOD']
    result['SERVER_NAME'] = request.META['SERVER_NAME']
    result['SERVER_PORT'] = request.META['SERVER_PORT']

    result['user_type'] = request.user.username

    return JsonResponse(result)


@require_GET
def json_response_test(request):
    """
    json 响应对象
    :param request:
    :return:
    """
    return JsonResponse({'name': 'qinyi', 'book': 'Django'})


@csrf_exempt
def method_check(request):
    html = "<h1>(%s) Hello Django BBS</h1>"
    return HttpResponse(html % request.method)


class ExecTimeMixin(object):
    @method_decorator(csrf_exempt)
    @method_decorator(exec_time)
    def dispatch(self, request, *args, **kwargs):
        return super(ExecTimeMixin, self).dispatch(request, *args, **kwargs)


class FirstView(ExecTimeMixin, View):
    html = '(%s) Hello Django BBS'

    # http_method_names = ['post']

    def get(self, request):
        return HttpResponse(self.html % 'GET')

    def post(self, request):
        return HttpResponse(self.html % 'POST')
    #
    # @method_decorator(csrf_exempt)
    # def dispatch(self, request, *args, **kwargs):
    #     return super(FirstView, self).dispatch(request, *args, **kwargs)


def dynamic_hello(request, month, year, day=15):
    html = "<h1>(%s) Hello Django BBS</h1>"
    print('-' * 100)
    callback, callback_args, callback_kwargs = request.resolver_match
    print(callback)
    print(callback_args)
    print(callback_kwargs)
    print(request.path)
    print('-' * 100)
    return HttpResponse(html % ('%s-%s-%s' % (year, month, day)))


def dynamic_hello_reverse(request):
    # print(reverse(dynamic_hello, kwargs={'year': 2018, 'day': 17, 'month': 9}))
    print(request.resolver_match.namespace)
    return HttpResponseRedirect(reverse('post:dynamic_hello', args=(2018, 9, 16),
                                        current_app=request.resolver_match.namespace))


class MonthConverter(IntConverter):
    regex = "0?[1-9]|1[0-2]"


@login_required
def topic_list_view(request):
    """
    话题列表
    :param request:
    :return:
    """
    print('进入到话题列表!!!!!!')
    topic_qs = Topic.objects.all()
    result = {
        'count': topic_qs.count(),
        'info': [build_topic_base_info(topic) for topic in topic_qs]
    }
    # return render(request, 'post/topic_list.html', result)
    return JsonResponse(result)


# @login_required
@permission_required(('post.can_view_topic', 'post.delete_topic'), raise_exception=True)
def topic_detail_view(request, topic_id):
    """
    话题详细信息
    :param request:
    :param topic_id:
    :return:
    """
    # print(foo)
    # print(request.build_absolute_uri())
    # result = {}
    topic = Topic.objects.get(id=topic_id)
    # topic = get_object_or_404(Topic.objects.filter(id__lte=10), pk__lt=topic_id)
    return JsonResponse(build_topic_detail_info(topic))
    # try:
    #     result = build_topic_detail_info(Topic.objects.get(pk=topic_id))
    # except Topic.DoesNotExist:
    #     pass
    # return JsonResponse(result)


@csrf_exempt
def add_comment_to_topic_view(request):
    """
    给话题添加评论
    :param request:
    :return:
    """
    topic_id = int(request.POST.get('id', 0))
    content = request.POST.get('content', '')
    topic = None

    try:
        topic = Topic.objects.get(pk=topic_id)
    except Topic.DoesNotExist:
        pass

    if topic and content:
        return JsonResponse({'id': add_comment_to_topic(topic, content).id})

    return JsonResponse({})


def hello_redirect(request):
    # class A:
    #     @classmethod
    #     def get_absolute_url(cls):
    #         return '/post/topic_list/'
    # return redirect(A)
    # return redirect('post:dynamic_hello', 2018, 9, 16)
    # return redirect('/post/topic_list/')
    return redirect('../topic_list/')


# =================================================== 基于类的通用视图 ====================================================
"""
View类提供了as_view()类方法，注意，这个方法只能当作类方法使用，不能用在实例上，它返回一个内方法view()，在这个方法中，
做的事情就是dispatch的事情，根据请求的方法，调用相应的方法去处理请求，如果你发送了一个GET请求，那么在view()方法中就会
分发到get()方法中去处理。View类就主要封装了这个功能，这个功能是最高层的抽象，所有的view都需要有这个特性。
"""


class IndexView(TemplateView):
    """
    https://blog.csdn.net/hackerain/article/details/40919789
    http://127.0.0.1:8000/post/index/
    @ 一步一步的说这个使用方法, 先不要提供 get_context_data 方法 : https://www.agiliq.com/blog/2017/12/when-and-how-use-django-templateview/
    这是Django提供的一个最简单的通用视图, 用于展示给定的模板, 不应该在这里实现创建或更新对象的操作
    适用于GET请求, 但是并不需要提供 get 方法, 因为 TemplateView 已经实现了 get 方法
    代码量偏多, 不够灵活, 但是面向对象的特性, 方法做不到代码复用(很难, 需要通过装饰器)
    index_view 与 IndexView 实现的功能是等价的

    它的好处是可以更加专注的实现业务逻辑, 避免了两类样板代码:
    1. 提供给 GET 类型请求的 get 方法
    2. 返回 HttpResponse 对象
    """
    template_name = 'post/index.html'    # 至少要指定模板文件名

    def get_context_data(self, **kwargs):
        context = super(IndexView, self).get_context_data(**kwargs)
        context['hello'] = 'Hello Django BBS'
        return context

    def get_template_names(self):
        # 实际就是在这个方法中返回 template_name
        return 'post/index.html'


def index_view(request):
    # http://127.0.0.1:8000/post/index_func/
    return render(request, 'post/index.html',
                  context={'hello': 'Hello Django BBS'})


class TopicList(ListView):
    """
    model=Article # 指定了数据表。他的功能相当于取出了Article中的所有数据
    template_name="blog/index.html" # 指定页面
    context_object_name="article_list" # listview 默认使用object_list作为上下文变量。可使用context_object_name重命名
    get_queryset(self) # 默认取出该表所有数据。想要过滤自定义只能在get_queryset()中
    get_context_data(self,**kwargs) # 这个方法用来添加额外的内容到上下文变量中
    """
    # http://127.0.0.1:8000/post/topics/
    # template_name = 'post/topic_list.html'
    # context_object_name = 'bbs_topic_list'
    # model = Topic
    # 设置 queryset 为列表
    # queryset = [Topic.objects.get(id=1)]
    # queryset = Topic.objects.all()
    # 设置这两个并截图 404 页面
    queryset = Topic.objects.filter(id__gt=10)
    allow_empty = False

    # paginate_by = 1       # 控制分页, 可不用细说


class CommentUpRedirectView(RedirectView):
    pattern_name = 'post:topic_detail'
    query_string = False

    def get_redirect_url(self, *args, **kwargs):
        comment = Comment.objects.get(pk=kwargs['comment_id'])
        comment.up = F('up') + 1
        comment.save()
        del kwargs['comment_id']
        kwargs['topic_id'] = comment.topic_id
        return super(CommentUpRedirectView, self).get_redirect_url(*args, **kwargs)


class TopicDetailView(DetailView):
    model = Topic

    def get_context_data(self, **kwargs):
        context = super(TopicDetailView, self).get_context_data(**kwargs)
        pk = self.kwargs.get(self.pk_url_kwarg)
        context.update({
            'comment_list': Comment.objects.filter(topic=pk)
        })
        return context


def search_topic_form(request):
    return render(request, 'post/search_topic.html', context={'form': TopicSearchForm()})


def search_topic(request):
    # if not request.GET.get('title', ''):
    #     errors = ['title is invalid!']
    #     return render(request, 'post/search_topic.html', context={'errors': errors})
    # topic_qs = Topic.objects.filter(title__contains=request.GET['title'])
    # return render(request, 'post/topic_list.html', context={'object_list': topic_qs})
    form = TopicSearchForm(request.GET)
    if form.is_valid():
        topic_qs = Topic.objects.filter(title__contains=form.cleaned_data['title'])
        return render(request, 'post/topic_list.html', context={'object_list': topic_qs})
    else:
        return render(request, 'post/search_topic.html', context={'form': form})


def topic_model_form(request):
    if request.method == 'POST':
        topic = TopicModelForm(request.POST)
        if topic.is_valid():
            # topic = Topic.objects.create(title=topic.cleaned_data['title'],
            #                              content=topic.cleaned_data['content'],
            #                              user=request.user)
            topic = topic.save(commit=False)
            topic.user = request.user
            topic.save()
            return topic_detail_view(request, topic.id)
        else:
            return render(request, 'post/topic_model_form.html',
                          context={'form': topic})
    else:
        return render(request, 'post/topic_model_form.html',
                      context={'form': TopicModelForm()})


def check_user(request):
    return render(request, 'post/check_user.html')


def check_permission(request):
    return render(request, 'post/check_permission.html')


def get_request(request):
    # a = request.GET['a']
    b = request.GET.get('b', 'y')
    c = request.GET.get('c', 'z')

    if hasattr(request, 'urlconf'):
        print('1111')
    else:
        print('222')
    print(request.path_info)
    return JsonResponse({})

    # print('%s-%s-%s' % (a, b, c))
    # raise Exception('server error')
    # return HttpResponse('<h1>GET Request</h1>')


def bad_request(request, exception, template_name='post/400.html'):
    return render(request, template_name)


def permission_denied(request, exception, template_name='post/403.html'):
    return render(request, template_name)


def page_not_found(request, exception, template_name='post/404.html'):
    return render(request, template_name)


def server_error(request, template_name='post/500.html'):
    return render(request, template_name)


# from functools import partial
#
#
# def signature_base(content, base):
#     int('10')
#     return '%s: %s' % (base, content)
#
#
# hello_signature = partial(signature_base, base='hello')
# django_signature = partial(signature_base, base='django')


def partial(func, *args, **kwargs):
    def newfunc(*fargs, **fkwargs):
        newkwargs = kwargs.copy()
        newkwargs.update(fkwargs)
        return func(*(args + fargs), **newkwargs)
    newfunc.func = func
    newfunc.args = args
    newfunc.kwargs = kwargs
    return newfunc


class AbstractHandle:

    def __init__(self):
        self.successor = None

    def set_successor(self, successor):
        self.successor = successor

    def handle(self, score):
        raise NotImplementedError


class HandleA(AbstractHandle):
    def handle(self, score):
        if 90 <= score <= 100:
            print('A')
        else:
            self.successor.handle(score)


class HandleB(AbstractHandle):
    def handle(self, score):
        if 75 <= score < 90:
            print('B')
        else:
            self.successor.handle(score)


class HandleC(AbstractHandle):
    def handle(self, score):
        if 60 <= score < 75:
            print('C')
        else:
            print('D')


handle_a = HandleA()
handle_b = HandleB()
handle_c = HandleC()


handle_a.set_successor(handle_b)
handle_b.set_successor(handle_c)


from django.dispatch import receiver
from django.core.signals import request_started, request_finished


# @receiver(request_started, dispatch_uid="request_started")
def request_started_callback(sender, **kwargs):
    print("request started: %s" % kwargs['environ'])


# @receiver(request_finished)
def request_finished_callback(sender, **kwargs):
    print("request finished")


# from django.core.signals import request_started, request_finished
# request_started.connect(request_started_callback, dispatch_uid="request_started")
# request_finished.connect(request_finished_callback)

# @receiver(request_started)
# def request_started_callback_2(sender, **kwargs):
#     print("request started_2")
