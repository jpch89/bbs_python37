import time
import unittest

from django.contrib.auth.models import User
from django.test import TestCase, tag

# Create your tests here.


# 需要数据库的测试（即模型测试）不会使用您的“真实”（生产）数据库。为测试创建单独的空白数据库。
# 无论测试通过还是失败，当所有测试都已执行时，测试数据库将被销毁。
# 您可以通过向测试命令添加 --keepdb 标志来防止测试数据库被破坏。这将在运行之间保留测试数据库。如果数据库不存在，它将首先被创建。
# 任何迁移也将应用，以保持最新。
# 默认情况下，测试数据库通过在DATABASES中定义的数据库的NAME设置的前面加上test_当使用SQLite数据库引擎时，测试将默认使用内存数据库
# （即，数据库将在内存中创建，完全绕过文件系统）。如果要使用其他数据库名称，请在DATABASES中的任何给定数据库的TEST字典中指定NAME


# 执行测试的顺序
# 为了保证所有TestCase代码以干净的数据库开始，Django测试运行器以下列方式重新排序测试：
#
# 所有TestCase子类首先运行。
# 然后，运行所有其他基于Django的测试（基于SimpleTestCase的测试用例，包括TransactionTestCase），而不保证或强制执行其中的特定顺序。
# 然后是任何其他unittest.运行可能更改数据库而不将其恢复到其原始状态的TestCase测试（包括doctests）。
# 注意
#
# 测试的新排序可能揭示对测试用例排序的意外依赖。这是依赖于通过给定的TransactionTestCase测试在数据库中保留的状态的doctests的情况，它们必须被更新以能够独立运行。
#
# 通过将--reverse传递到测试命令，可以反转组内的执行顺序。这可以帮助确保您的测试彼此独立。

# ./PYTHON.sh manage.py test --settings=settings-test clinic.ChunyuClinicTest.test_get_chunyu_clinic_detail

# python manage.py test -h
# python manage.py test --settings=settings-test post.tests
# coverage run --source='.' manage.py test --settings=settings-test post
# coverage report


from post.models import Topic


# @unittest.skip("skip SimpleTest")
# @unittest.expectedFailure
# @tag('minor')
class SimpleTest(TestCase):

    # # @unittest.skip("skip test a")
    # def test_a(self):
    #     print('running test a')
    #
    # # @unittest.skipIf(2 > 1, "skip test b")
    # def test_b(self):
    #     print('running test b')
    #
    # # @unittest.skipUnless(2 < 1, "skip test c")
    # def test_c(self):
    #     print('running test c')
    #     self.assertEqual(1, 2)
    #
    # # @unittest.expectedFailure
    # def test_fail(self):
    #     self.assertEqual(0, 1)

    # @classmethod
    # def setUpClass(cls):
    #     print('running setUpClass')

    # @classmethod
    # def tearDownClass(cls):
    #     print('running tearDownClass')
    #
    def setUp(self):
        # print('running setUp')
        self.user = User.objects.create_user(username='username',
                                             password='password')

    # @unittest.skip('skip test_basic_addition')
    def test_addition(self):
        """
        Tests that 1 + 1 always equals 2.
        # Run all the tests in the post.tests module
        $  python manage.py test post.tests
        # Run all the tests found within the 'post' package
        $ python manage.py test post
        # Run just one test case
        $ python manage.py test post.tests.SimpleTest
        # Run just one test method
        $ python manage.py test post.tests.SimpleTest.test_basic_addition

        python manage.py test --settings=settings-test post.tests
        """
        def addition(x, y):
            return x + y
        self.assertEqual(addition(1, 1), 2)

    @tag('major')
    def test_post_topic_model(self):
        # print('running test_post_topic_model')
        topic = Topic.objects.create(
            title='test topic', content='first test topic', user=self.user
        )
        self.assertTrue(topic is not None)
        self.assertEqual(Topic.objects.count(), 1)
        topic.delete()
        self.assertEqual(Topic.objects.count(), 0)

    @tag('major')
    def test_topic_detail_view(self):
        # print('running test_topic_detail_view')
        topic = Topic.objects.create(
            title='test topic', content='first test topic', user=self.user
        )
        response = self.client.get('/post/topic/%d/' % topic.id)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()['id'], topic.id)

    @tag('minor')
    def test_custom_assert(self):
        with self.assertRaisesMessage(ValueError, 'invalid literal for int()'):
            int('a')

        self.assertHTMLNotEqual("<h1>hello bbs</h1>", "  <h1>hello bbs</h1>")
        # self.assertXMLEqual()
        # self.assertXMLNotEqual()

        self.assertJSONEqual('{"a": 1, "b": 2}', '{"b": 2, "a": 1}')
        self.assertJSONNotEqual('{"a": 1, "b": 2}', '{"c": 2, "a": 1}')

        topic = Topic.objects.create(
            title='test topic', content='first test topic', user=self.user
        )
        self.assertQuerysetEqual(Topic.objects.all(), [repr(topic)])

        topic_1 = Topic.objects.create(
            title='test topic 1', content='first test topic', user=self.user
        )
        topic_2 = Topic.objects.create(
            title='test topic 2', content='second test topic', user=self.user
        )
        self.assertQuerysetEqual(Topic.objects.all(), [repr(topic_2), repr(topic_1)], ordered=False)

        with self.assertNumQueries(2):
            Topic.objects.count()
            Topic.objects.filter(user=self.user).count()

    #
    # def tearDown(self):
    #     print('running tearDown')
