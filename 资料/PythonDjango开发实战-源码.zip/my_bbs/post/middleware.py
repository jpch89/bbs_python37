import json

from django.http import JsonResponse, HttpRequest, HttpResponse
from django.utils.deprecation import MiddlewareMixin


class MeaninglessMiddleware(MiddlewareMixin):
    pass


class FirstMiddleware(MiddlewareMixin):

    # def __init__(self, get_response=None):
    #     self.get_response = get_response
    #     print('初始化')
    #     super().__init__()

    def process_request(self, request):
        print('FirstMiddleware: process_request')
        # return JsonResponse({'Hello': 'Django BBS'})

    def process_view(self, request, view_func, view_args, view_kwargs):
        print('FirstMiddleware: process_view')
        # return JsonResponse({'Hello': 'Django BBS'})

    # def process_view(self, request, view_func, view_args, view_kwargs):
    #     if isinstance(request, HttpRequest):
    #         print('request 是 HttpRequest 对象实例')
    #     print(type(view_args))
    #     print(type(view_kwargs))
    #     # return JsonResponse({'hello': 'hahaha'})

    def process_template_response(self, request, response):
        print('FirstMiddleware: process_template_response')

        def render():
            print('hello_django_bbs: render')
            return JsonResponse({'hello': 'render'})

        response = HttpResponse()
        response.render = render
        return response

        # return JsonResponse({'hello': 'render'})
        # return response

    def process_exception(self, request, exception):
        print('FirstMiddleware: process_exception')
        # return JsonResponse({'exception': str(exception)})

    def process_response(self, request, response):
        print('FirstMiddleware: process_response')
        # print('%s: %s %s' % (request.path_info, request.user.id or "-1", request.META['REMOTE_ADDR']))
        return response


class SecondMiddleware(MiddlewareMixin):

    def process_request(self, request):
        print('SecondMiddleware: process_request')

    def process_view(self, request, view_func, view_args, view_kwargs):
        print('SecondMiddleware: process_view')

    def process_response(self, request, response):
        print('SecondMiddleware: process_response')
        return response
        # print(response.content)
        # return JsonResponse({
        #     'middleware': json.loads(response.content),
        #     'status': 0,
        # })


class ThirdMiddleware(MiddlewareMixin):

    def process_request(self, request):
        print('ThirdMiddleware: process_request')

    def process_response(self, request, response):
        print('ThirdMiddleware: process_response')
        return response

