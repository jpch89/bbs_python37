# 在每个应用中自己创建

from django.urls import path, register_converter, re_path
# from django.utils.translation import gettext_lazy

from post import views
from post.views import FirstView, MonthConverter

register_converter(MonthConverter, 'mth')

app_name = 'post'

urlpatterns = [
    path('hello/', views.hello_django_bbs, name='hello'),
    path('hello_class/', FirstView.as_view()),
    path('second_hello_class/', FirstView.as_view(html='Second: (%s) Hello Django BBS')),
    path('dynamic/<int:year>/<mth:month>/', views.dynamic_hello),
    path('dynamic/<int:year>/<mth:month>/<int:day>/', views.dynamic_hello, name='dynamic_hello'),
    path('dynamic/', views.dynamic_hello_reverse),
    re_path('re_dynamic/(?P<year>[0-9]{4})/(?P<month>[0-9]{2})/(?P<day>[0-9]{2})/', views.dynamic_hello),
    # re_path('re_dynamic/([0-9]{4})/([0-9]{2})/([0-9]{2})/', views.dynamic_hello),
    path('topic_list/', views.topic_list_view),
    # path('topic/<int:topic_id>/', views.topic_detail_view, kwargs={'topic_id': '2'}, name='topic_detail'),
    path('topic/<int:topic_id>/', views.topic_detail_view, name='topic_detail'),
    path('topic_comment/', views.add_comment_to_topic_view),
    path('hello_redirect/', views.hello_redirect),
    path('get_request/', views.get_request),

    # 基于类的通用视图
    path('index/', views.IndexView.as_view()),
    path('index_func/', views.index_view),
    path('comment_up/<int:comment_id>/', views.CommentUpRedirectView.as_view()),
    path('topics/', views.TopicList.as_view()),
    path('topic_view/<int:pk>/', views.TopicDetailView.as_view()),

    # path('method/', views.method_check),
    # path('json/', views.json_response_test),
    # path('property/', views.request_property),

    path('search_topic_form/', views.search_topic_form),
    path('search_topic/', views.search_topic),

    path('topic_model_form/', views.topic_model_form),

    path('check_user/', views.check_user),
    path('check_permission/', views.check_permission),
]
