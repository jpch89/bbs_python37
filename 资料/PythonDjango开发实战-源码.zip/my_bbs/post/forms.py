from django import forms


# def gender_func():
#     return (
#         ('M', 'male'),
#         ('F', 'female')
#     )
from post.models import Topic


class TopicSearchForm(forms.Form):
    title = forms.CharField(label='Topic title')
    a = forms.CharField(widget=forms.HiddenInput())
    b = forms.CharField()

    def clean_title(self):
        title = self.cleaned_data['title']
        if len(title) < 5:
            raise forms.ValidationError("字符串长度太短!")
        return title


class TopicModelForm(forms.ModelForm):

    # title = forms.IntegerField()
    # x = forms.IntegerField()

    class Meta:
        model = Topic
        exclude = ('is_online', 'user')
        # fields = '__all__'
        # labels = {
        #     'title': '标题',
        #     'content': '内容',
        # }
        # help_texts = {
        #     'title': '简短的话题标题',
        #     'content': '话题的详细内容',
        # }
        # from django.forms import widgets
        # widgets = {
        #     "content": widgets.Textarea(attrs={'cols': '60', 'rows': '5'})
        # }
        # field_classes = {
        #     'title': forms.EmailField
        # }
        # error_messages = {
        #     'title': {
        #         'required': '话题标题不能为空',
        #         'invalid': '话题标题存在重复',
        #     },
        #     'content': {
        #         'required': '话题标题不能为空',
        #         'invalid': '话题标题存在重复',
        #     },
        # }


# class ExampleForm(forms.Form):
#     a = forms.CharField(max_length=10)
#     b = forms.CharField(required=False)
#     c = forms.IntegerField(min_value=0, max_value=10)


# from django.core.exceptions import ValidationError
# from post.models import Topic
#
#
# class TopicField(forms.Field):
#     default_error_messages = {
#         'invalid': 'Enter a whole number.',
#         'not_exist': 'Model Not Exist',
#     }
#
#     def to_python(self, value):
#         try:
#             value = int(str(value).strip())
#             return Topic.objects.get(pk=value)
#         except (ValueError, TypeError):
#             raise ValidationError(self.error_messages['invalid'], code='invalid')
#         except Topic.DoesNotExist:
#             raise ValidationError(self.error_messages['not_exist'], code='not_exist')
#
#
# def even_validator(value):
#     if value % 2 != 0:
#         raise ValidationError('%d is not a even number' % value)
#
#
# class EvenField(forms.IntegerField):
#     def __init__(self, **kwargs):
#         super().__init__(validators=[even_validator], **kwargs)
#
#
# class SignField(forms.CharField):
#     def clean(self, value):
#         return 'django %s' % super().clean(value)
#

















