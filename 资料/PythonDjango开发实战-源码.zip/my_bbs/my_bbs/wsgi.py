"""
WSGI config for my_bbs project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more information on this file, see
https://docs.djangoproject.com/en/2.0/howto/deployment/wsgi/
"""

# http://hawk.pub/x/icJ394Av.html
import sys
# sys.path.append('/Users/zhanghu05/my_django_book/bbs_python37/lib/python3.7/site-packages')

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "my_bbs.settings")
application = get_wsgi_application()
