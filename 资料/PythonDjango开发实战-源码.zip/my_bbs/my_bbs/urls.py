"""my_bbs URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.contrib.auth.views import LoginView
from django.urls import path, include


from post import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('post/', include('post.urls', namespace='bbs_post')),
    path('login/', LoginView.as_view(template_name='post/login.html')),

    path('post_2/', include(
        (
            [path('index/', views.IndexView.as_view()), path('hello/', views.hello_django_bbs)],
            'post'
        ),
        namespace='bbs_post2'
    )),
]


handler400 = views.bad_request
handler403 = views.permission_denied
handler404 = views.page_not_found
handler500 = views.server_error
