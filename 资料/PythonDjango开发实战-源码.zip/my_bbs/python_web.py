from wsgiref.simple_server import make_server


def application(environ, start_response):
    print(environ)
    status = '200 OK'
    response_headers = [('Content-type', 'text/plain')]
    start_response(status, response_headers)
    return [b"Hello World!\n"]


# class AppClass:
#
#     def __init__(self, environ, start_response):
#         self.environ = environ
#         self.start_response = start_response
#
#     def __iter__(self):
#         status = '200 OK'
#         response_headers = [('Content-type', 'text/plain')]
#         self.start_response(status, response_headers)
#         yield b"Hello World!\n"
#
#
# class AppClass2:
#
#     def __init__(self):
#         pass
#
#     def __call__(self, environ, start_response):
#         status = '200 OK'
#         response_headers = [('Content-type', 'text/plain')]
#         start_response(status, response_headers)
#         yield b"Hello World!\n"


httpd = make_server('127.0.0.1', 8000, application)
httpd.handle_request()
